# loathebrotate
WoW Classic addon for Loatheb healing rotation
