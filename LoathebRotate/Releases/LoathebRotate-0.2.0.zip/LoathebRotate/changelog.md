## LoathebRotate Changelog

#### v0.1.0 (2024-04-04)
- Branched from SilentRotate version 1.0.1 by Vinny
- Updated ACE3 libraries to newest version
- Fixed a few issues with the 1.15.x client.

